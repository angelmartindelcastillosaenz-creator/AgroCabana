# **App Name**: AgroCabana

## Core Features:

- Product Catalog Display: Displays all available agricultural products, each presented as a card with an image, name, price, available quantity, description snippet, and farmer's name. Users can browse these products.
- Product Search & Category Filtering: Allows users to search for specific products by name and filter listings by predefined categories (Papa, Trigo, Habas, Maíz, Quinua, Otros).
- Product Submission Form: Provides a comprehensive form for farmers to easily list new products, capturing details such as product name, price, quantity, unit (kg, saco, tonelada), detailed description, photo upload, farmer's name, contact phone number, and district.
- Individual Product Detail View: Presents a dedicated page for each product, showcasing all its information comprehensively and allowing users to view more specific details before making a decision.
- Direct Farmer Contact (WhatsApp): Integrates a direct button on each product's detail page, enabling users to contact the respective farmer instantly via WhatsApp for inquiries or purchase negotiations.
- AI Product Description Tool: A generative AI tool integrated into the product submission form to assist farmers in creating engaging and informative product descriptions by suggesting content based on product type and basic information.
- Responsive Layout & Navigation: Ensures the application's interface adapts seamlessly across mobile phones, tablets, and desktop computers, complemented by a clear navigation menu and an informative footer.

## Style Guidelines:

- Primary color: A sophisticated, muted green (#267339), chosen to evoke the natural environment of agriculture and instill a sense of professionalism and trustworthiness, ensuring good contrast with light backgrounds.
- Background color: An extremely light, desaturated green (#EBF6EE), providing a clean, fresh, and modern canvas that subtly hints at agricultural themes while maintaining an open, airy feel.
- Accent color: A vibrant, fresh green (#8DE618), positioned to provide a striking visual contrast to the primary color, drawing attention to calls-to-action and key interactive elements.
- Headline and body font: 'Inter' (sans-serif) for its modern, clean, and highly readable design across all screen sizes, supporting a professional yet user-friendly interface.
- Use clean, modern, and easily recognizable icons related to agriculture, products (e.g., categories like papa, trigo), and user interactions (e.g., search, contact).
- Implement a responsive grid-based layout for product listings, detail pages, and forms, ensuring optimal content display and navigation consistency across mobile, tablet, and desktop devices.
- Subtle and purposeful animations for user feedback, such as loading states, form submissions, and hover effects on product cards or buttons, to enhance the perceived fluidity and responsiveness of the application.