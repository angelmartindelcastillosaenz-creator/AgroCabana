
'use server';
/**
 * @fileOverview Un agente de IA para editar y mejorar fotos de productos agrícolas.
 *
 * - editProductImage - Función que maneja la edición de imágenes con Gemini.
 * - EditImageInput - Tipo de entrada para la función.
 * - EditImageOutput - Tipo de salida para la función.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const EditImageInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "La foto original del producto como URI de datos base64."
    ),
  instruction: z.string().describe('Instrucción para editar la imagen (ej. "coloca las papas sobre una mesa de madera rústica").'),
});
export type EditImageInput = z.infer<typeof EditImageInputSchema>;

const EditImageOutputSchema = z.object({
  editedImageUrl: z.string().describe('La URL de la imagen editada en formato base64.'),
});
export type EditImageOutput = z.infer<typeof EditImageOutputSchema>;

export async function editProductImage(input: EditImageInput): Promise<EditImageOutput> {
  return editProductImageFlow(input);
}

const editProductImageFlow = ai.defineFlow(
  {
    name: 'editProductImageFlow',
    inputSchema: EditImageInputSchema,
    outputSchema: EditImageOutputSchema,
  },
  async input => {
    const {media} = await ai.generate({
      model: 'googleai/gemini-2.5-flash-image',
      prompt: [
        {media: {url: input.photoDataUri}},
        {text: `Eres un editor de fotos experto para mercados agrícolas. Sigue esta instrucción de edición para mejorar la presentación del producto: ${input.instruction}. Mantén el producto principal reconocible y realista.`},
      ],
      config: {
        responseModalities: ['TEXT', 'IMAGE'],
      },
    });

    if (!media) {
      throw new Error('No se pudo generar la imagen editada.');
    }

    return {
      editedImageUrl: media.url,
    };
  }
);
