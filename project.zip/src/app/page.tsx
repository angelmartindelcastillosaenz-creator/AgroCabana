"use client";

import { useState, useEffect, useMemo } from 'react';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { ProductCard } from '@/components/catalog/ProductCard';
import { getProducts } from '@/lib/data-service';
import { Product, CATEGORIES, Category } from '@/lib/types';
import { Input } from '@/components/ui/input';
import { Search, SlidersHorizontal } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';

export default function Home() {
  const [products, setProducts] = useState<Product[]>([]);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'Todos'>('Todos');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const data = getProducts();
    setProducts(data);
    setIsLoading(false);
  }, []);

  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      const matchesSearch = product.name.toLowerCase().includes(search.toLowerCase()) ||
                          product.description.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = selectedCategory === 'Todos' || product.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [products, search, selectedCategory]);

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-primary text-primary-foreground py-16 md:py-24 overflow-hidden relative">
          <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/ancash/1200/800')] opacity-10 bg-cover bg-center" />
          <div className="container mx-auto px-4 text-center relative z-10">
            <h1 className="text-4xl md:text-6xl font-extrabold mb-4 font-headline tracking-tight leading-tight">
              Mercado Agrícola <br className="hidden md:block" />
              de Cabana, Áncash
            </h1>
            <p className="text-lg md:text-xl text-primary-foreground/90 max-w-2xl mx-auto mb-8">
              Compra directamente de los mejores productores de la provincia de Pallasca. 
              Frescura garantizada del campo a tu mesa.
            </p>
            <div className="max-w-xl mx-auto relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground group-focus-within:text-primary transition-colors" />
              <Input
                placeholder="Busca papas, quinua, trigo..."
                className="pl-12 h-14 bg-white text-foreground rounded-full shadow-xl border-none text-lg"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
        </section>

        {/* Filters and Catalog */}
        <section className="container mx-auto px-4 py-12">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
            <div className="flex items-center space-x-2 overflow-x-auto pb-2 md:pb-0 no-scrollbar">
              <Badge
                variant={selectedCategory === 'Todos' ? 'default' : 'outline'}
                className="cursor-pointer px-4 py-1.5 text-sm"
                onClick={() => setSelectedCategory('Todos')}
              >
                Todos
              </Badge>
              {CATEGORIES.map(category => (
                <Badge
                  key={category}
                  variant={selectedCategory === category ? 'default' : 'outline'}
                  className="cursor-pointer px-4 py-1.5 text-sm whitespace-nowrap"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Badge>
              ))}
            </div>
            <div className="text-sm text-muted-foreground">
              Mostrando {filteredProducts.length} productos
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="space-y-4">
                  <Skeleton className="aspect-square w-full rounded-xl" />
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              ))}
            </div>
          ) : filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {filteredProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-white rounded-3xl border-2 border-dashed border-muted">
              <p className="text-muted-foreground text-lg">No se encontraron productos con esos criterios.</p>
              <Button 
                variant="link" 
                onClick={() => {setSearch(''); setSelectedCategory('Todos');}}
                className="mt-2 text-primary"
              >
                Limpiar filtros
              </Button>
            </div>
          )}
        </section>
      </main>

      <Footer />
    </div>
  );
}