
"use client";

import { useState, useEffect, useRef } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CATEGORIES, DISTRICTS, UNITS, Category, Product } from '@/lib/types';
import { getProductById, updateProduct } from '@/lib/data-service';
import { Sparkles, Loader2, ArrowLeft, Image as ImageIcon, Wand2, Upload } from 'lucide-react';
import { editProductImage } from '@/ai/flows/edit-product-image';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';

export default function EditProductPage() {
  const params = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [aiInstruction, setAiInstruction] = useState('');

  const [formData, setFormData] = useState<Partial<Product>>({
    name: '',
    price: 0,
    quantity: 0,
    unit: 'kg',
    category: 'Otros',
    description: '',
    farmerName: '',
    phone: '',
    district: 'Cabana',
    imageUrl: ''
  });

  useEffect(() => {
    if (params.id) {
      const product = getProductById(params.id as string);
      if (product) {
        setFormData(product);
      } else {
        router.push('/');
      }
    }
  }, [params.id, router]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, imageUrl: reader.result as string }));
        toast({
          title: "Imagen cargada",
          description: "La foto se ha subido correctamente desde tu galería.",
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAiEditImage = async () => {
    if (!formData.imageUrl) return;
    
    setIsAiLoading(true);
    try {
      const result = await editProductImage({
        photoDataUri: formData.imageUrl,
        instruction: aiInstruction || "Mejora la iluminación y pon el producto sobre un fondo de granja rústico.",
      });
      
      setFormData(prev => ({ ...prev, imageUrl: result.editedImageUrl }));
      toast({
        title: "¡Imagen editada!",
        description: "La IA ha procesado tu foto.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "No pudimos editar la imagen con IA.",
        variant: "destructive"
      });
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      updateProduct(params.id as string, formData);
      toast({
        title: "Actualizado",
        description: "Los cambios han sido guardados.",
      });
      router.push(`/product/${params.id}`);
    } catch (error) {
      toast({
        title: "Error",
        description: "No se pudo actualizar el producto.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow bg-muted/30 py-12">
        <div className="container mx-auto px-4 max-w-4xl">
          <Button 
            variant="ghost" 
            className="mb-6 -ml-2 text-muted-foreground hover:text-primary"
            onClick={() => router.back()}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Cancelar
          </Button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Sidebar de Imagen */}
            <div className="lg:col-span-1 space-y-6">
              <div className="bg-white p-6 rounded-3xl shadow-lg border">
                <Label className="mb-4 block">Imagen del Producto</Label>
                <div className="relative aspect-square rounded-2xl overflow-hidden mb-4 border group cursor-pointer" onClick={() => fileInputRef.current?.click()}>
                  {formData.imageUrl ? (
                    <Image 
                      src={formData.imageUrl} 
                      alt="Preview" 
                      fill 
                      className="object-cover transition-opacity group-hover:opacity-80"
                    />
                  ) : (
                    <div className="flex items-center justify-center h-full bg-muted">
                      <ImageIcon className="h-12 w-12 text-muted-foreground" />
                    </div>
                  )}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20 text-white font-medium text-sm">
                    <Upload className="mr-2 h-4 w-4" /> Cambiar foto
                  </div>
                </div>
                
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={handleFileChange} 
                />

                <Button 
                  variant="outline" 
                  className="w-full mb-6"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Upload className="mr-2 h-4 w-4" />
                  Subir desde galería
                </Button>
                
                <div className="space-y-4">
                  <div className="p-4 bg-primary/5 rounded-xl border border-primary/10">
                    <p className="text-xs font-semibold text-primary uppercase mb-2 flex items-center">
                      <Wand2 className="h-3 w-3 mr-1" /> Editar con IA
                    </p>
                    <Input 
                      placeholder="Ej: Ponlo en una mesa rústica"
                      className="text-sm mb-2"
                      value={aiInstruction}
                      onChange={e => setAiInstruction(e.target.value)}
                    />
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full text-xs h-9 border-primary text-primary hover:bg-primary/5"
                      onClick={handleAiEditImage}
                      disabled={isAiLoading || !formData.imageUrl}
                    >
                      {isAiLoading ? <Loader2 className="h-3 w-3 animate-spin mr-2" /> : <Sparkles className="h-3 w-3 mr-2" />}
                      Aplicar cambios IA
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Formulario Principal */}
            <div className="lg:col-span-2">
              <div className="bg-white p-8 md:p-10 rounded-3xl shadow-xl border">
                <h1 className="text-2xl font-bold text-primary mb-6">Editar Producto</h1>
                
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nombre</Label>
                      <Input 
                        id="name" 
                        value={formData.name}
                        onChange={e => setFormData({...formData, name: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="category">Categoría</Label>
                      <Select 
                        value={formData.category} 
                        onValueChange={v => setFormData({...formData, category: v as any})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="price">Precio (S/)</Label>
                      <Input 
                        id="price" 
                        type="number" 
                        value={formData.price}
                        onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="quantity">Cantidad</Label>
                      <Input 
                        id="quantity" 
                        type="number" 
                        value={formData.quantity}
                        onChange={e => setFormData({...formData, quantity: parseFloat(e.target.value)})}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="unit">Unidad</Label>
                      <Select 
                        value={formData.unit} 
                        onValueChange={v => setFormData({...formData, unit: v as any})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {UNITS.map(u => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Descripción</Label>
                    <Textarea 
                      id="description" 
                      rows={4}
                      value={formData.description}
                      onChange={e => setFormData({...formData, description: e.target.value})}
                    />
                  </div>

                  <div className="pt-6 border-t flex gap-4">
                    <Button 
                      type="submit" 
                      className="flex-1 h-12 text-lg" 
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? <Loader2 className="h-5 w-5 animate-spin mr-2" /> : 'Guardar Cambios'}
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
