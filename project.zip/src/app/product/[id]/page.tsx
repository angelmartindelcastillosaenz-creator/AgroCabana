
"use client";

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { Product } from '@/lib/types';
import { getProductById } from '@/lib/data-service';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, User, Phone, Calendar, ArrowLeft, MessageCircle, Edit3 } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function ProductDetailPage() {
  const params = useParams();
  const router = useRouter();
  const [product, setProduct] = useState<Product | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (params.id) {
      const data = getProductById(params.id as string);
      setProduct(data);
    }
    setIsLoading(false);
  }, [params.id]);

  if (isLoading) {
    return <div className="min-h-screen bg-background flex flex-col items-center justify-center">Cargando...</div>;
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <h1 className="text-2xl font-bold mb-4">Producto no encontrado</h1>
        <Button onClick={() => router.push('/')}>Volver al inicio</Button>
      </div>
    );
  }

  const handleWhatsApp = () => {
    const message = encodeURIComponent(`Hola ${product.farmerName}, vi tu anuncio de ${product.name} en AgroCabana y estoy interesado.`);
    window.open(`https://wa.me/51${product.phone}?text=${message}`, '_blank');
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow py-8 md:py-16 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-6">
            <Button 
              variant="ghost" 
              className="text-muted-foreground hover:text-primary"
              onClick={() => router.back()}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver a la búsqueda
            </Button>
            
            <Link href={`/product/${product.id}/edit`}>
              <Button variant="outline" size="sm" className="border-primary text-primary hover:bg-primary/5">
                <Edit3 className="mr-2 h-4 w-4" />
                Editar producto
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Product Image */}
            <div className="relative aspect-square md:aspect-video lg:aspect-square overflow-hidden rounded-3xl shadow-2xl">
              <Image
                src={product.imageUrl}
                alt={product.name}
                fill
                className="object-cover"
                data-ai-hint="agricultural product closeup"
              />
              <Badge className="absolute top-6 left-6 text-base px-4 py-1.5 shadow-lg bg-primary">
                {product.category}
              </Badge>
            </div>

            {/* Product Info */}
            <div className="flex flex-col">
              <div className="flex-grow">
                <h1 className="text-4xl md:text-5xl font-extrabold text-primary mb-4 font-headline tracking-tight">
                  {product.name}
                </h1>
                
                <div className="flex items-center space-x-4 mb-8">
                  <div className="text-3xl font-bold text-foreground">
                    S/ {product.price.toFixed(2)}
                    <span className="text-lg text-muted-foreground font-normal ml-2">por {product.unit}</span>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-6 mb-8 border border-primary/5 shadow-sm">
                  <h3 className="font-semibold text-primary mb-3">Descripción</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {product.description}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="flex items-start space-x-3">
                    <div className="mt-1 p-2 bg-secondary rounded-lg">
                      <User className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Producido por</p>
                      <p className="font-semibold text-foreground">{product.farmerName}</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="mt-1 p-2 bg-secondary rounded-lg">
                      <MapPin className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Ubicación</p>
                      <p className="font-semibold text-foreground">{product.district}, Ancash</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="mt-1 p-2 bg-secondary rounded-lg">
                      <Phone className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Contacto</p>
                      <p className="font-semibold text-foreground">{product.phone}</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <div className="mt-1 p-2 bg-secondary rounded-lg">
                      <Calendar className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Publicado el</p>
                      <p className="font-semibold text-foreground">
                        {format(new Date(product.createdAt), "d 'de' MMMM, yyyy", { locale: es })}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="sticky bottom-6 flex flex-col sm:flex-row gap-4 mt-8 pt-8 border-t">
                <Button 
                  onClick={handleWhatsApp} 
                  className="flex-1 h-16 text-lg bg-[#25D366] hover:bg-[#128C7E] border-none shadow-lg text-white"
                >
                  <MessageCircle className="mr-2 h-6 w-6" />
                  Contactar por WhatsApp
                </Button>
                <div className="bg-white px-6 py-4 rounded-xl border flex flex-col justify-center items-center sm:items-start shadow-sm">
                  <span className="text-xs text-muted-foreground uppercase font-bold tracking-widest">Disponibles</span>
                  <span className="text-xl font-bold text-primary">{product.quantity} {product.unit}s</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
