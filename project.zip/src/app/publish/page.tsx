
"use client";

import { useState, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CATEGORIES, DISTRICTS, UNITS, Category } from '@/lib/types';
import { saveProduct } from '@/lib/data-service';
import { Sparkles, Loader2, ArrowLeft, Upload, Image as ImageIcon } from 'lucide-react';
import { generateProductDescription } from '@/ai/flows/generate-product-description';
import { useToast } from '@/hooks/use-toast';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Image from 'next/image';

export default function PublishPage() {
  const router = useRouter();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    price: '',
    quantity: '',
    unit: 'kg' as any,
    category: 'Otros' as Category,
    description: '',
    farmerName: '',
    phone: '',
    district: 'Cabana',
    imageUrl: ''
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, imageUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAiDescription = async () => {
    if (!formData.name || !formData.category) {
      toast({
        title: "Información insuficiente",
        description: "Ingresa el nombre del producto y categoría para usar la IA.",
        variant: "destructive"
      });
      return;
    }

    setIsAiLoading(true);
    try {
      const result = await generateProductDescription({
        productName: formData.name,
        productType: formData.category,
      });
      setFormData(prev => ({ ...prev, description: result.description }));
    } catch (error) {
      toast({
        title: "Error",
        description: "No pudimos generar la descripción en este momento.",
        variant: "destructive"
      });
    } finally {
      setIsAiLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // If no image uploaded, get a random placeholder image based on category if possible
    let finalImageUrl = formData.imageUrl;
    if (!finalImageUrl) {
      const imgId = formData.category.toLowerCase();
      finalImageUrl = PlaceHolderImages.find(img => img.id.includes(imgId))?.imageUrl || PlaceHolderImages[0].imageUrl;
    }

    try {
      saveProduct({
        name: formData.name,
        price: parseFloat(formData.price),
        quantity: parseFloat(formData.quantity),
        unit: formData.unit,
        category: formData.category,
        description: formData.description,
        imageUrl: finalImageUrl,
        farmerName: formData.farmerName,
        phone: formData.phone,
        district: formData.district
      });
      
      toast({
        title: "¡Éxito!",
        description: "Tu producto ha sido publicado correctamente.",
      });

      router.push('/');
    } catch (error) {
      toast({
        title: "Error",
        description: "Hubo un problema al publicar tu producto.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow bg-muted/30 py-12">
        <div className="container mx-auto px-4 max-w-3xl">
          <Button 
            variant="ghost" 
            className="mb-6 -ml-2 text-muted-foreground hover:text-primary"
            onClick={() => router.back()}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Volver
          </Button>

          <div className="bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-primary/5">
            <h1 className="text-3xl font-bold text-primary mb-2 font-headline">Publica tu producto</h1>
            <p className="text-muted-foreground mb-8">Completa la información para que los compradores puedan encontrarte.</p>

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Image Upload Section */}
              <div className="space-y-4">
                <Label>Foto del producto</Label>
                <div 
                  className="relative aspect-video rounded-2xl overflow-hidden border-2 border-dashed border-muted hover:border-primary/50 transition-colors cursor-pointer flex flex-col items-center justify-center bg-muted/20"
                  onClick={() => fileInputRef.current?.click()}
                >
                  {formData.imageUrl ? (
                    <Image src={formData.imageUrl} alt="Preview" fill className="object-cover" />
                  ) : (
                    <div className="text-center p-6">
                      <ImageIcon className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm font-medium text-muted-foreground">Haz clic para subir una foto desde tu galería</p>
                    </div>
                  )}
                </div>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={handleFileChange} 
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Nombre del producto</Label>
                  <Input 
                    id="name" 
                    placeholder="Ej. Papa Amarilla Yungay" 
                    required 
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Categoría</Label>
                  <Select 
                    value={formData.category} 
                    onValueChange={v => setFormData({...formData, category: v as any})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Selecciona categoría" />
                    </SelectTrigger>
                    <SelectContent>
                      {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="price">Precio (S/)</Label>
                  <Input 
                    id="price" 
                    type="number" 
                    step="0.10" 
                    placeholder="0.00" 
                    required 
                    value={formData.price}
                    onChange={e => setFormData({...formData, price: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="quantity">Cantidad disponible</Label>
                  <Input 
                    id="quantity" 
                    type="number" 
                    placeholder="10" 
                    required 
                    value={formData.quantity}
                    onChange={e => setFormData({...formData, quantity: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="unit">Unidad</Label>
                  <Select 
                    value={formData.unit} 
                    onValueChange={v => setFormData({...formData, unit: v as any})}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {UNITS.map(u => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-end mb-2">
                  <Label htmlFor="description">Descripción del producto</Label>
                  <Button 
                    type="button" 
                    variant="outline" 
                    size="sm" 
                    className="text-primary border-primary hover:bg-primary/5 h-8 text-xs"
                    onClick={handleAiDescription}
                    disabled={isAiLoading}
                  >
                    {isAiLoading ? (
                      <Loader2 className="mr-2 h-3 w-3 animate-spin" />
                    ) : (
                      <Sparkles className="mr-2 h-3 w-3" />
                    )}
                    Generar con IA
                  </Button>
                </div>
                <Textarea 
                  id="description" 
                  rows={4} 
                  placeholder="Describe la calidad, procedencia y usos de tu producto..." 
                  required
                  value={formData.description}
                  onChange={e => setFormData({...formData, description: e.target.value})}
                />
              </div>

              <div className="pt-6 border-t">
                <h3 className="text-lg font-semibold mb-4 text-primary">Información del Agricultor</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="farmerName">Nombre completo</Label>
                    <Input 
                      id="farmerName" 
                      placeholder="Tu nombre" 
                      required 
                      value={formData.farmerName}
                      onChange={e => setFormData({...formData, farmerName: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Celular (WhatsApp)</Label>
                    <Input 
                      id="phone" 
                      placeholder="999000111" 
                      required 
                      value={formData.phone}
                      onChange={e => setFormData({...formData, phone: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="district">Distrito</Label>
                    <Select 
                      value={formData.district} 
                      onValueChange={v => setFormData({...formData, district: v})}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {DISTRICTS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Button type="submit" className="w-full h-12 text-lg" disabled={isSubmitting}>
                {isSubmitting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : 'Publicar Producto Ahora'}
              </Button>
            </form>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
