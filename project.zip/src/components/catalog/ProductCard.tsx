import Image from 'next/image';
import Link from 'next/link';
import { User, MapPin, Tag } from 'lucide-react';
import { Product } from '@/lib/types';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface ProductCardProps {
  product: Product;
}

export function ProductCard({ product }: ProductCardProps) {
  return (
    <Card className="overflow-hidden group hover:shadow-lg transition-all duration-300 border-none bg-card/50 backdrop-blur-sm">
      <Link href={`/product/${product.id}`} className="block">
        <div className="relative aspect-square overflow-hidden">
          <Image
            src={product.imageUrl}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            data-ai-hint="agricultural product"
          />
          <Badge className="absolute top-2 right-2 bg-primary/90 hover:bg-primary">
            {product.category}
          </Badge>
        </div>
        <CardContent className="p-4">
          <h3 className="text-lg font-bold text-primary line-clamp-1 mb-1 font-headline">
            {product.name}
          </h3>
          <div className="flex items-baseline space-x-1 mb-2">
            <span className="text-xl font-bold text-foreground">S/ {product.price.toFixed(2)}</span>
            <span className="text-xs text-muted-foreground">/ {product.unit}</span>
          </div>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-4 h-10">
            {product.description}
          </p>
          <div className="flex flex-col space-y-1.5 pt-2 border-t text-xs text-muted-foreground">
            <div className="flex items-center">
              <User className="h-3 w-3 mr-1.5" />
              <span>{product.farmerName}</span>
            </div>
            <div className="flex items-center">
              <MapPin className="h-3 w-3 mr-1.5" />
              <span>{product.district}</span>
            </div>
            <div className="flex items-center">
              <Tag className="h-3 w-3 mr-1.5" />
              <span>{product.quantity} {product.unit}s disponibles</span>
            </div>
          </div>
        </CardContent>
      </Link>
      <CardFooter className="p-4 pt-0">
        <Link href={`/product/${product.id}`} className="w-full">
          <Button variant="outline" className="w-full text-primary border-primary hover:bg-primary hover:text-white">
            Ver detalles
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}