import { Sprout } from 'lucide-react';

export function Footer() {
  return (
    <footer className="w-full bg-secondary py-12 border-t">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center text-center md:text-left">
          <div className="space-y-4">
            <div className="flex items-center justify-center md:justify-start space-x-2">
              <Sprout className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold text-primary tracking-tight font-headline">
                AgroCabana
              </span>
            </div>
            <p className="text-sm text-muted-foreground max-w-xs mx-auto md:mx-0">
              Conectando a los agricultores de Cabana, Áncash con el mundo. Productos frescos, directos de la tierra.
            </p>
          </div>
          <div className="space-y-4">
            <h3 className="font-semibold text-primary">Enlaces rápidos</h3>
            <ul className="text-sm text-muted-foreground space-y-2">
              <li>Inicio</li>
              <li>Categorías</li>
              <li>Cómo vender</li>
              <li>Términos y condiciones</li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="font-semibold text-primary">Contacto</h3>
            <p className="text-sm text-muted-foreground">
              Cabana, Pallasca, Áncash, Perú<br />
              info@agrocabana.pe
            </p>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-muted text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} AgroCabana. Todos los derechos reservados.
        </div>
      </div>
    </footer>
  );
}