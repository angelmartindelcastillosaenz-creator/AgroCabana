"use client";

import Link from 'next/link';
import { Sprout, PlusCircle, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function Navbar() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <Sprout className="h-6 w-6" />
            </div>
            <span className="text-xl font-bold text-primary tracking-tight font-headline">
              AgroCabana
            </span>
          </Link>

          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-sm font-medium hover:text-primary transition-colors">
              Inicio
            </Link>
            <Link href="/publish" className="text-sm font-medium hover:text-primary transition-colors">
              Vender
            </Link>
          </nav>

          <div className="flex items-center space-x-4">
            <Link href="/publish" passHref>
              <Button className="hidden sm:flex" size="sm">
                <PlusCircle className="mr-2 h-4 w-4" />
                Publicar producto
              </Button>
            </Link>
            <Link href="/publish" passHref className="sm:hidden">
              <Button size="icon" variant="outline">
                <PlusCircle className="h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}