
import { Product, CATEGORIES } from './types';
import { PlaceHolderImages } from './placeholder-images';

const STORAGE_KEY = 'agrocabana_products';

const DEFAULT_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Papa Amarilla de Altura',
    price: 3.5,
    quantity: 500,
    unit: 'kg',
    category: 'Papa',
    description: 'Papa amarilla cosechada orgánicamente a más de 3500 msnm en las faldas de Cabana. Ideal para puré y sancochado.',
    imageUrl: PlaceHolderImages.find(img => img.id === 'potato')?.imageUrl || '',
    farmerName: 'Lucio Paredes',
    phone: '987654321',
    district: 'Cabana',
    createdAt: new Date().toISOString()
  },
  {
    id: '2',
    name: 'Trigo Centeno Limpio',
    price: 120,
    quantity: 15,
    unit: 'saco',
    category: 'Trigo',
    description: 'Trigo de excelente calidad, libre de impurezas. Listo para molienda en los molinos tradicionales de la zona.',
    imageUrl: PlaceHolderImages.find(img => img.id === 'wheat')?.imageUrl || '',
    farmerName: 'Marta Solís',
    phone: '912345678',
    district: 'Huandoval',
    createdAt: new Date().toISOString()
  },
  {
    id: '3',
    name: 'Maíz Blanco Gigante',
    price: 5.0,
    quantity: 1000,
    unit: 'kg',
    category: 'Maíz',
    description: 'Maíz de grano grande y dulce, perfecto para mote o tostado. Cultivado en las andenerías de Tauca.',
    imageUrl: PlaceHolderImages.find(img => img.id === 'corn')?.imageUrl || '',
    farmerName: 'Roberto Díaz',
    phone: '999888777',
    district: 'Tauca',
    createdAt: new Date().toISOString()
  },
  {
    id: '4',
    name: 'Quinua Roja Orgánica',
    price: 8.5,
    quantity: 200,
    unit: 'kg',
    category: 'Quinua',
    description: 'Quinua roja con alto valor nutricional, lavada y seleccionada manualmente por productores de Cabana.',
    imageUrl: PlaceHolderImages.find(img => img.id === 'quinoa')?.imageUrl || '',
    farmerName: 'Elena García',
    phone: '955444333',
    district: 'Cabana',
    createdAt: new Date().toISOString()
  },
  {
    id: '5',
    name: 'Habas Verdes Frescas',
    price: 4.5,
    quantity: 300,
    unit: 'kg',
    category: 'Habas',
    description: 'Habas frescas recién cosechadas de las chacras de Llapo. Tiernas y de gran tamaño.',
    imageUrl: PlaceHolderImages.find(img => img.id === 'andean-village')?.imageUrl || 'https://picsum.photos/seed/beans/800/600',
    farmerName: 'Simón Manrique',
    phone: '944333222',
    district: 'Llapo',
    createdAt: new Date().toISOString()
  }
];

export const getProducts = (): Product[] => {
  if (typeof window === 'undefined') return DEFAULT_PRODUCTS;
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_PRODUCTS));
    return DEFAULT_PRODUCTS;
  }
  return JSON.parse(stored);
};

export const getProductById = (id: string): Product | undefined => {
  return getProducts().find(p => p.id === id);
};

export const saveProduct = (product: Omit<Product, 'id' | 'createdAt'>): Product => {
  const newProduct: Product = {
    ...product,
    id: Math.random().toString(36).substr(2, 9),
    createdAt: new Date().toISOString()
  };
  const current = getProducts();
  const updated = [newProduct, ...current];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  return newProduct;
};

export const updateProduct = (id: string, updates: Partial<Product>): Product | undefined => {
  const current = getProducts();
  const index = current.findIndex(p => p.id === id);
  if (index === -1) return undefined;
  
  const updatedProduct = { ...current[index], ...updates };
  const newList = [...current];
  newList[index] = updatedProduct;
  
  localStorage.setItem(STORAGE_KEY, JSON.stringify(newList));
  return updatedProduct;
};
