export type Category = 'Papa' | 'Trigo' | 'Habas' | 'Maíz' | 'Quinua' | 'Otros';

export interface Product {
  id: string;
  name: string;
  price: number;
  quantity: number;
  unit: 'kg' | 'saco' | 'tonelada';
  description: string;
  category: Category;
  imageUrl: string;
  farmerName: string;
  phone: string;
  district: string;
  createdAt: string;
}

export const CATEGORIES: Category[] = ['Papa', 'Trigo', 'Habas', 'Maíz', 'Quinua', 'Otros'];
export const DISTRICTS = ['Cabana', 'Huandoval', 'Bolognesi', 'Tauca', 'Llapo', 'Santa Rosa', 'Pallasca'];
export const UNITS = ['kg', 'saco', 'tonelada'];